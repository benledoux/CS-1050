/**    
  *  @author Noel LeJeune
  *  @version  2012.01.23.01
  *  ObjectTester
  *  
  */

import java.util.Scanner;

public class ObjectTester
{
   // instance variables (fields)
   
   public Scanner stdIn;
   
   // constructors
   public ObjectTester()
   {
      stdIn = new Scanner(System.in);
   }   
   // instance methods
   public String getInputString()
   {
      System.out.print("Enter a String: ");
      return stdIn.nextLine();
   }
   
   public int getInputInt()
   {
      System.out.print("Enter an int: ");
      return Integer.parseInt(stdIn.nextLine());
   }
   
   public double getInputDouble()
   {
      System.out.print("Enter a double: ");
      return Double.parseDouble(stdIn.nextLine());
   }
   
   public char getInputChar()
   {
      System.out.print("Enter a char: ");
      return stdIn.nextLine().charAt(0);
   }
   
   public void testSphere()
   {
      System.out.println("\n================ BEGIN Testing Sphere Class ===============");
      System.out.println("Create a Sphere object, sphere1, using No-Arg Constructor");
      Sphere sphere1 = new Sphere();
      System.out.println("Examine the object sphere1 using the outputInfo() method");
      sphere1.outputInfo();
      System.out.println("Create a Sphere object, sphere2, using Constructor with an argument of 3.3");
      Sphere sphere2 = new Sphere(3.3);
      System.out.println("Examine the object sphere2 using the outputInfo() method");
      sphere2.outputInfo();
      System.out.println();
      
      System.out.println("Change the radius of sphere1 using setRadius(4.1) method");
      sphere1.setRadius(4.1);
      System.out.println("Check sphere1 with the get radius() method to see that the radius is 4.1");      
      System.out.println("Get the radius");
      double r = sphere1.getRadius();
      System.out.println("The radius is " + r);
      System.out.println();
      
      System.out.println("Test the calculateSurfaceArea() method for sphere2");
      sphere2.outputInfo();
      double area = sphere2.calculateSurfaceArea();
      System.out.println("The surface area of sphere2 is " + area);
      System.out.println();
      
      System.out.println("Test the calculateVolume() method for sphere1");
      sphere1.outputInfo();
      double volume = sphere1.calculateVolume();
      System.out.println("The volume of sphere1 is " + volume);
      System.out.println();
            
      System.out.println("Creating yet another Sphere object");
      Sphere sphere3 = new Sphere(2.0);
      sphere3.outputInfo();
      System.out.println("------------------------------------");
      System.out.println("The info for the three spheres");
      System.out.println("------------------------------------");
      sphere1.outputInfo();
      sphere2.outputInfo();
      sphere3.outputInfo();
      System.out.println("================ END Testing Sphere Class ===============\n");
   }
   
   public void testRectangle()
   {
      System.out.println("\n================ BEGIN Testing Rectangle Class ===============");
      // Insert your code here
   
      System.out.println("================ END Testing Rectangle Class ===============\n");   
   }

   public void testDie()
   {
      System.out.println("\n================ BEGIN Testing Die Class ===============");
      // Insert your code here
   
      System.out.println("================ END Testing Die Class ===============\n");   
   }
   
   public void testDice()
   {
      System.out.println("\n================ BEGIN Testing Dice Class ===============");
      // Insert your code here
   
      System.out.println("================ END Testing Dice Class ===============\n");   
   }
   
   public void testBlock()
   {
      System.out.println("\n================ BEGIN Testing Block Class ===============");
      // Insert your code here
   
      System.out.println("================ END Testing Block Class ===============\n");   
   }

   
   // class methods
   public static void main(String[] args)
   {
      ObjectTester myTester = new ObjectTester();
      myTester.testSphere();
      myTester.testRectangle();
   }
}
















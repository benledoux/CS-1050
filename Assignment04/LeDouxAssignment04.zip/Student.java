/* Ben LeDoux
	CS 1050
	4/5/12
	Assignment04
	*/
	
	import java.util.*;
	
	public class Student
	{
		private String name;
		private ArrayList<Double> Tests;
		private static Scanner keys = new Scanner(System.in);
		
		public Student(String name, ArrayList<Double> Tests)
		{
			Tests = new ArrayList<Double>();
			this.name = name;
			this.Tests = Tests;
		}
		
		public Student(String name)
		{
			this.name = name;
			Tests = new ArrayList<Double>();
		}
		
		
		public void setScore(double score, Student stu)
		{
			stu.Tests.add(score);
		}
		
		public String grades(ArrayList<Student> stu)
		{
			String str = " ";
			
			for(int index =0; index < Tests.size(); index++)
			{
				str += " " + Tests.get(index);
			}
			return str;	
		}
		
		public Double high(ArrayList<Student> stu)
		{
			if(Tests.size() == 0)
			{
				return 0.0;
			}
			double high = Tests.get(0);
			
			for(int h=1; h < Tests.size(); h++)
			{
				if(Tests.get(h) > high)
				{
					high = Tests.get(h);
				}
			}
			
		return high;
		}
		
		public Double low(ArrayList<Student> stu)
		{
			if(Tests.size() == 0)
			{
				return 0.0;
			}
			double low = Tests.get(0);
			
			for(int l=1; l < Tests.size(); l++)
			{
				if(Tests.get(l) < low)
				{
					low = Tests.get(l);
				}
			}
			return low;
		}
		
		public Double total(ArrayList<Student> stu)
		{
			double total = 0;
			if(Tests.size() == 0)
			{
				return 0.0;
			}
			for(int a=0; a < Tests.size(); a++)
			{
				total = total + Tests.get(a);
			}
			return total;
		}
		
		public String toString(ArrayList<Student> stu)
		{   	
			return name + "\n" + grades(stu) + "\n" + "Tests: " + Tests.size() + " High score: " + high(stu) + " Low score: " + low(stu) + " Total: " + total(stu); 
		}
		
	}

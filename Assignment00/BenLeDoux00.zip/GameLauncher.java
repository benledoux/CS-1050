/**
  * @author Ben LeDoux
  * @version 2012.01.17.01
  * @since 2012.01.17
  * Program00
  */
  
  public class GameLauncher
  {
  		public static void main(String[] args)
		{
			GuessGame game = new GuessGame();
			game.run();
		}
	}
	
/**    
  *  @author Ben LeDoux
  *  @version 2012.02.23.12
  *  SimpleATM
  *  
  */



public class SimpleATM
{

	
	public SimpleATM()
	{
	}
	
		
	public static void main (String[ ] args)
{
	Customer cust = new Customer();
	cust.run();
}

}


	

